@echo off
title RTO Digital Assistant Web Server
clear-host 2>nul || cls

echo =========================================================
echo              RTO Digital Assistant Server Launcher
echo =========================================================
echo.

:: Check for Python
where python >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Starting local web server on port 8000 using Python...
    :: python http.server binds to 0.0.0.0 (all interfaces) by default
    start /b python -m http.server 8000 >nul 2>&1
    goto :started
)

:: Check for Node/NPX
where npx >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo Starting local web server on port 8000 using Node/NPX...
    :: npx serve binds to 0.0.0.0 by default when using -l (listen) or -p
    start /b npx serve -p 8000 >nul 2>&1
    goto :started
)

echo Error: Neither Python nor Node/NPX was found in your system's PATH.
echo Please install Python or Node.js to run this local mockup server.
echo.
pause
exit /b

:started
:: Wait 2 seconds to let the server start
ping 127.0.0.1 -n 3 >nul

echo.
echo ---------------------------------------------------------
echo Server is successfully running!
echo.
echo Access locally on this laptop:
echo   -> http://localhost:8000
echo.
echo Access from your phone (when connected to Laptop's Hotspot):
:: Query active IPv4 addresses (excluding loopback and APIPA addresses)
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { Write-Host '  -> http://' $_.IPAddress ':8000' -ForegroundColor Yellow }"
echo.
echo (Normally, Windows Hotspot uses the IP address 192.168.137.1)
echo ---------------------------------------------------------
echo.
echo -^> PRESS ANY KEY inside this window to STOP the server.
echo -^> CLOSING this window will also terminate the server.
echo.
pause >nul

echo.
echo Stopping web server running on port 8000...
:: Find the process ID listening on port 8000 and kill it
for /f "tokens=5" %%a in ('netstat -aon ^| findstr /r /c:":8000 "') do (
    taskkill /f /pid %%a >nul 2>&1
)

echo Server stopped successfully. Goodbye!
ping 127.0.0.1 -n 2 >nul
exit
