/* ==========================================================================
   RTO Digital Assistant - Interactive Client Logic & Accessibility
   ========================================================================== */

// Global State
let currentLanguage = 'en';
let currentFontSize = 'md'; // sm, md, lg, xl
let activeTheme = 'light'; // light, dark, contrast

// Bilingual UI Text Map
const uiStrings = {
    en: {
        welcome: "Namaste! Welcome to the RTO Digital Assistant. I am designed to help citizens of Uttarakhand find RTO information easily.<br><br>Feel free to ask me anything about <strong>Driving Licenses</strong>, <strong>Vehicle RC</strong>, or <strong>Challans</strong>.",
        placeholder: "Type your message here...",
        btnSpeak: "Read this message aloud",
        listening: "Listening...",
        hint: 'Say something like: "How do I renew my license?"',
        simulateBtn: 'Simulate Voice: "How to check DL status?"',
        defaultReply: "I will be ready soon...",
        voiceResult: "How to check driving license status?",
        workingHours: "Working Hours: 10:00 AM - 5:00 PM (Mon-Sat)",
        senderAssistant: "RTO Sahayak",
        senderUser: "You"
    },
    hi: {
        welcome: "नमस्ते! आरटीओ डिजिटल सहायक में आपका स्वागत है। मुझे उत्तराखंड के नागरिकों को आसानी से आरटीओ जानकारी खोजने में मदद करने के लिए डिज़ाइन किया गया है।<br><br>आप मुझसे <strong>ड्राइविंग लाइसेंस</strong>, <strong>वाहन आरसी</strong>, या <strong>चालान</strong> के बारे में कुछ भी पूछ सकते हैं।",
        placeholder: "अपना संदेश यहाँ लिखें...",
        btnSpeak: "इस संदेश को ज़ोर से पढ़ें",
        listening: "सुन रहा हूँ...",
        hint: 'कुछ इस तरह बोलें: "मैं अपना लाइसेंस कैसे नवीनीकृत करूँ?"',
        simulateBtn: 'आवाज सिमुलेशन: "ड्राइविंग लाइसेंस स्टेटस?"',
        defaultReply: "मैं जल्द ही तैयार हो जाऊंगा...",
        voiceResult: "ड्राइविंग लाइसेंस की स्थिति कैसे जांचें?",
        workingHours: "कार्य समय: सुबह 10:00 - शाम 5:00 (सोमवार से शनिवार)",
        senderAssistant: "आरटीओ सहायक",
        senderUser: "आप"
    }
};

// --------------------------------------------------------------------------
// Sidebar Drawer Toggle (Mobile View)
// --------------------------------------------------------------------------

function toggleSidebar(open) {
    const sidebar = document.getElementById('info-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (!sidebar || !overlay) return;

    if (open) {
        sidebar.classList.add('open');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden'; // Stop body scrolling under drawer
    } else {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// --------------------------------------------------------------------------
// Accessibility: Text Resizing & Themes
// --------------------------------------------------------------------------

function adjustTextSize(action) {
    const body = document.body;
    
    // Remove all text size classes
    body.classList.remove('text-sm', 'text-md', 'text-lg', 'text-xl');
    
    // Determine next size
    if (action === 'up') {
        if (currentFontSize === 'sm') currentFontSize = 'md';
        else if (currentFontSize === 'md') currentFontSize = 'lg';
        else if (currentFontSize === 'lg') currentFontSize = 'xl';
    } else if (action === 'down') {
        if (currentFontSize === 'xl') currentFontSize = 'lg';
        else if (currentFontSize === 'lg') currentFontSize = 'md';
        else if (currentFontSize === 'md') currentFontSize = 'sm';
    } else {
        currentFontSize = 'md'; // reset
    }
    
    // Add current class
    body.classList.add(`text-${currentFontSize}`);
    
    // Update active button state
    document.getElementById('font-decrease').classList.remove('active');
    document.getElementById('font-reset').classList.remove('active');
    document.getElementById('font-increase').classList.remove('active');
    
    if (currentFontSize === 'sm') document.getElementById('font-decrease').classList.add('active');
    if (currentFontSize === 'md') document.getElementById('font-reset').classList.add('active');
    if (currentFontSize === 'lg' || currentFontSize === 'xl') document.getElementById('font-increase').classList.add('active');
}

function setTheme(themeName) {
    const body = document.body;
    body.classList.remove('theme-light', 'theme-dark', 'theme-contrast');
    body.classList.add(`theme-${themeName}`);
    activeTheme = themeName;
    
    // Update button states
    document.getElementById('theme-light').classList.remove('active');
    document.getElementById('theme-dark').classList.remove('active');
    document.getElementById('theme-contrast').classList.remove('active');
    
    document.getElementById(`theme-${themeName}`).classList.add('active');
}

// --------------------------------------------------------------------------
// Accessibility: Language Toggles (English / Hindi)
// --------------------------------------------------------------------------

function setLanguage(lang) {
    currentLanguage = lang;
    
    // Update toggle button states
    document.getElementById('lang-en').classList.remove('active');
    document.getElementById('lang-hi').classList.remove('active');
    document.getElementById('lang-en').setAttribute('aria-pressed', 'false');
    document.getElementById('lang-hi').setAttribute('aria-pressed', 'false');
    
    document.getElementById(`lang-${lang}`).classList.add('active');
    document.getElementById(`lang-${lang}`).setAttribute('aria-pressed', 'true');
    
    // Translate standard UI text blocks
    document.getElementById('user-input').placeholder = uiStrings[lang].placeholder;
    
    // Translate working hours in sidebar
    const workingHoursElement = document.querySelector('.working-hours');
    if (workingHoursElement) {
        workingHoursElement.textContent = uiStrings[lang].workingHours;
    }
    
    // Translate help topics in sidebar (data-attributes)
    document.querySelectorAll('.help-link-text span').forEach(span => {
        const text = span.getAttribute(`data-${lang}`);
        if (text) {
            span.textContent = text;
        }
    });

    // Translate suggestions row chips
    const suggestionsRow = document.getElementById('suggestions-row');
    if (suggestionsRow) {
        if (lang === 'hi') {
            suggestionsRow.innerHTML = `
                <button type="button" class="suggestion-chip" onclick="applySuggestion('लर्निंग लाइसेंस की आवश्यकताएं')">लर्निंग लाइसेंस की आवश्यकताएं</button>
                <button type="button" class="suggestion-chip" onclick="applySuggestion('आरसी स्टेटस चेक करें')">आरसी स्टेटस चेक करें</button>
                <button type="button" class="suggestion-chip" onclick="applySuggestion('चालान का भुगतान कैसे करें?')">चालान का भुगतान कैसे करें?</button>
            `;
        } else {
            suggestionsRow.innerHTML = `
                <button type="button" class="suggestion-chip" onclick="applySuggestion('Learning License Requirements')">Learning License Requirements</button>
                <button type="button" class="suggestion-chip" onclick="applySuggestion('Check RC Status')">Check RC Status</button>
                <button type="button" class="suggestion-chip" onclick="applySuggestion('How to pay Challan?')">How to pay Challan?</button>
            `;
        }
    }

    // Dynamic translate greeting message if it is the only/first message
    const welcomeMsg = document.getElementById('welcome-msg');
    if (welcomeMsg && welcomeMsg.closest('.message').nextElementSibling === null) {
        welcomeMsg.innerHTML = uiStrings[lang].welcome;
    }
}

// --------------------------------------------------------------------------
// Accessibility: Text-to-Speech (Audio assistance)
// --------------------------------------------------------------------------

function speakMessage(btnElement) {
    // Find text inside the message bubble
    const messageContent = btnElement.closest('.message-content');
    const textElement = messageContent.querySelector('.message-text');
    const textToSpeak = textElement.textContent || textElement.innerText;
    
    // Toggle speaking state
    if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        resetSpeakButtons();
        return;
    }
    
    // Set up Speech Synthesis
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    
    // Attempt to match Hindi vs English voice
    const voices = window.speechSynthesis.getVoices();
    if (currentLanguage === 'hi') {
        const hiVoice = voices.find(voice => voice.lang.includes('hi') || voice.lang.includes('IN'));
        if (hiVoice) utterance.voice = hiVoice;
    } else {
        const enVoice = voices.find(voice => voice.lang.includes('en') || voice.lang.includes('US') || voice.lang.includes('GB'));
        if (enVoice) utterance.voice = enVoice;
    }
    
    // Adjust rate for seniors (slightly slower than normal)
    utterance.rate = 0.85; 
    
    // Change speaker icon to visual "stop" animation
    btnElement.innerHTML = '<i class="fa-solid fa-circle-stop" style="color: #ef4444;"></i>';
    btnElement.setAttribute('aria-label', 'Stop reading');
    
    utterance.onend = () => {
        resetSpeakButtons();
    };
    
    utterance.onerror = () => {
        resetSpeakButtons();
    };
    
    window.speechSynthesis.speak(utterance);
}

function resetSpeakButtons() {
    document.querySelectorAll('.btn-speak').forEach(btn => {
        btn.innerHTML = '<i class="fa-solid fa-volume-high"></i>';
        btn.setAttribute('aria-label', uiStrings[currentLanguage].btnSpeak);
    });
}

// Ensure voices are loaded (needed in some browsers)
if (typeof speechSynthesis !== 'undefined' && speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = () => {};
}

// --------------------------------------------------------------------------
// Voice-to-Text Mockup Overlay & Simulation
// --------------------------------------------------------------------------

function toggleVoiceInput() {
    const overlay = document.getElementById('voice-overlay');
    const isVisible = overlay.style.display !== 'none';
    
    if (isVisible) {
        overlay.style.display = 'none';
        overlay.setAttribute('aria-hidden', 'true');
    } else {
        // Reset state inside overlay
        document.getElementById('voice-status').textContent = uiStrings[currentLanguage].listening;
        overlay.style.display = 'flex';
        overlay.setAttribute('aria-hidden', 'false');
    }
}

function simulateVoiceInput() {
    const statusText = document.getElementById('voice-status');
    const inputVal = uiStrings[currentLanguage].voiceResult;
    
    statusText.textContent = "Processing speech...";
    
    // Simulate words appearing letter by letter like dictation
    setTimeout(() => {
        toggleVoiceInput();
        
        // Put text into input box
        const inputField = document.getElementById('user-input');
        inputField.value = inputVal;
        
        // Animate input text box container for highlight
        const wrapper = document.querySelector('.input-wrapper');
        wrapper.style.borderColor = 'var(--primary)';
        
        setTimeout(() => {
            wrapper.style.borderColor = 'var(--border-color)';
            // Submit the form automatically
            document.getElementById('chat-form').dispatchEvent(new Event('submit'));
        }, 800);
        
    }, 1500);
}

// --------------------------------------------------------------------------
// Chat Logic & User Flows
// --------------------------------------------------------------------------

function appendMessage(sender, text) {
    const chatFeed = document.getElementById('chat-messages');
    const msgElement = document.createElement('div');
    msgElement.className = `message ${sender}`;
    
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const senderName = sender === 'assistant' ? uiStrings[currentLanguage].senderAssistant : uiStrings[currentLanguage].senderUser;
    const avatarIcon = sender === 'assistant' ? '<i class="fa-solid fa-headset"></i>' : '<i class="fa-solid fa-user"></i>';
    
    // Build structural HTML for message bubble
    msgElement.innerHTML = `
        <div class="avatar" aria-hidden="true">${avatarIcon}</div>
        <div class="message-content">
            <div class="message-header">
                <span class="sender-name">${senderName}</span>
                ${sender === 'assistant' ? `<button class="btn-speak" onclick="speakMessage(this)" aria-label="${uiStrings[currentLanguage].btnSpeak}"><i class="fa-solid fa-volume-high"></i></button>` : ''}
            </div>
            <div class="message-text">${text}</div>
            <span class="message-time">${timeString}</span>
        </div>
    `;
    
    chatFeed.appendChild(msgElement);
    chatFeed.scrollTop = chatFeed.scrollHeight;
}

function showTypingIndicator() {
    const chatFeed = document.getElementById('chat-messages');
    const indicator = document.createElement('div');
    indicator.className = 'message assistant typing-indicator-item';
    indicator.id = 'typing-indicator';
    
    indicator.innerHTML = `
        <div class="avatar" aria-hidden="true"><i class="fa-solid fa-headset"></i></div>
        <div class="message-content typing-bubble">
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        </div>
    `;
    
    chatFeed.appendChild(indicator);
    chatFeed.scrollTop = chatFeed.scrollHeight;
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
        indicator.remove();
    }
}

// Process the form submission
function handleFormSubmit(event) {
    event.preventDefault();
    
    const inputField = document.getElementById('user-input');
    const userQuery = inputField.value.trim();
    if (!userQuery) return;
    
    // 1. Post user message
    appendMessage('user', userQuery);
    inputField.value = '';
    
    // 2. Show agent typing indicator
    showTypingIndicator();
    
    // 3. Trigger delayed mock response
    setTimeout(() => {
        hideTypingIndicator();
        
        // Match specific phrases to make mockup feel richer, but fallback to requested default
        let reply = uiStrings[currentLanguage].defaultReply;
        const queryLower = userQuery.toLowerCase();
        
        if (currentLanguage === 'en') {
            if (queryLower.includes('license') || queryLower.includes('dl')) {
                reply = "I understand you are asking about Driving License services. <strong>RTO Digital Assistant</strong> will soon be able to walk you through applications, renewals, and slots. <br><br><em>(Demo Reply: I will be ready soon...)</em>";
            } else if (queryLower.includes('rc') || queryLower.includes('registration')) {
                reply = "I understand you are asking about Vehicle Registration (RC). Soon, you can check owners, fitness certificates, and hypothecations directly here. <br><br><em>(Demo Reply: I will be ready soon...)</em>";
            } else if (queryLower.includes('challan') || queryLower.includes('fine')) {
                reply = "I see your query is regarding traffic Challans. The future assistant will fetch pending challan details and let you pay via safe payment gateways. <br><br><em>(Demo Reply: I will be ready soon...)</em>";
            }
        } else { // Hindi custom mockups
            if (queryLower.includes('लाइसेंस') || queryLower.includes('license')) {
                reply = "मैं समझ सकता हूँ कि आप ड्राइविंग लाइसेंस सेवाओं के बारे में पूछ रहे हैं। <strong>आरटीओ डिजिटल सहायक</strong> जल्द ही आपको स्लॉट बुकिंग और आवेदन की जानकारी देने में सक्षम होगा। <br><br><em>(डेमो उत्तर: मैं जल्द ही तैयार हो जाऊंगा...)</em>";
            } else if (queryLower.includes('आरसी') || queryLower.includes('पंजीकरण') || queryLower.includes('rc')) {
                reply = "मैं समझता हूँ कि आपका प्रश्न वाहन पंजीकरण (RC) के संबंध में है। जल्द ही आप यहाँ से वाहन के मालिक का विवरण और फिटनेस प्रमाणपत्र देख सकेंगे। <br><br><em>(डेमो उत्तर: मैं जल्द ही तैयार हो जाऊंगा...)</em>";
            }
        }
        
        appendMessage('assistant', reply);
    }, 1200);
}

// --------------------------------------------------------------------------
// Interaction Shortcuts (Suggestions and Sidebar links)
// --------------------------------------------------------------------------

function applySuggestion(text) {
    const inputField = document.getElementById('user-input');
    inputField.value = text;
    inputField.focus();
}

function sendQuickQuery(topicId) {
    let queryText = '';
    
    if (topicId === 'apply-license') {
        queryText = currentLanguage === 'en' ? "How do I apply for a new Driving License?" : "नया ड्राइविंग लाइसेंस कैसे बनवाएं?";
    } else if (topicId === 'vehicle-rc') {
        queryText = currentLanguage === 'en' ? "How to check my Vehicle RC status?" : "अपने वाहन का आरसी स्टेटस कैसे जांचें?";
    } else if (topicId === 'pay-challan') {
        queryText = currentLanguage === 'en' ? "Steps to pay traffic challan online?" : "ट्रैफिक चालान ऑनलाइन भरने की प्रक्रिया?";
    } else if (topicId === 'book-slot') {
        queryText = currentLanguage === 'en' ? "Book driving test slot at Uttarakhand RTO" : "उत्तराखंड आरटीओ में ड्राइविंग टेस्ट स्लॉट बुक करें";
    }
    
    if (queryText) {
        // Close sidebar drawer on mobile
        toggleSidebar(false);
        
        const inputField = document.getElementById('user-input');
        inputField.value = queryText;
        document.getElementById('chat-form').dispatchEvent(new Event('submit'));
    }
}
